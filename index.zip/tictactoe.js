class Board {
    //Initializing the board
    constructor(state = ['','','','','','','','','']) {
        this.state = state;
    }
    //Logs a visualised board with the current state to the console
    printFormattedBoard() {
        let formattedString = '';
        this.state.forEach((cell, index) => {
            formattedString += cell ? ` ${cell} |` : '   |';
            if((index + 1) % 3 == 0)  {
                formattedString = formattedString.slice(0,-1);
                if(index < 8) formattedString += '\n\u2015\u2015\u2015 \u2015\u2015\u2015 \u2015\u2015\u2015\n';
            }
        });
        console.log('%c' + formattedString, 'color: #6d4e42;font-size:16px');
    }
    //Checks if board has no symbols yet
    isEmpty() {
        return this.state.every(cell => !cell);
    }
    //Check if board has no spaces available
    isFull() {
        return this.state.every(cell => cell);
    }
    /**
     * Inserts a new symbol(x,o) into
     * @param {String} symbol 
     * @param {Number} position
     * @return {Boolean} boolean represent success of the operation
     */
    insert(symbol, position) {
        if(position > 8 || this.state[position]) return false; //Cell is either occupied or does not exist
        this.state[position] = symbol;
        return true;
    }
    //Returns an array containing available moves for the current state
    getAvailableMoves() {
        const moves = [];
        this.state.forEach((cell, index) => {
            if(!cell) moves.push(index); 
        });
        return moves;
    }
    /**
     * Checks if the board has a terminal state ie. a player wins or the board is full with no winner
     * @return {Object} an object containing the winner, direction of winning and row number
     */
    isTerminal() {
        //Return False if board in empty
        if(this.isEmpty()) return false;

        //Checking Horizontal Wins
        if(this.state[0] == this.state[1] && this.state[0] == this.state[2] && this.state[0]) {
            return {'winner': this.state[0], 'direction': 'H', 'row': 1};
        }
        if(this.state[3] == this.state[4] && this.state[3] == this.state[5] && this.state[3]) {
            return {'winner': this.state[3], 'direction': 'H', 'row': 2};
        }
        if(this.state[6] == this.state[7] && this.state[6] == this.state[8] && this.state[6]) {
            return {'winner': this.state[6], 'direction': 'H', 'row': 3};
        }

        //Checking Vertical Wins
        if(this.state[0] == this.state[3] && this.state[0] == this.state[6] && this.state[0]) {
            return {'winner': this.state[0], 'direction': 'V', 'row': 1};
        }
        if(this.state[1] == this.state[4] && this.state[1] == this.state[7] && this.state[1]) {
            return {'winner': this.state[1], 'direction': 'V', 'row': 2};
        }
        if(this.state[2] == this.state[5] && this.state[2] == this.state[8] && this.state[2]) {
            return {'winner': this.state[2], 'direction': 'V', 'row': 3};
        }

        //Checking Diagonal Wins
        if(this.state[0] == this.state[4] && this.state[0] == this.state[8] && this.state[0]) {
            return {'winner': this.state[0], 'direction': 'D', 'row': 1};
        }
        if(this.state[2] == this.state[4] && this.state[2] == this.state[6] && this.state[2]) {
            return {'winner': this.state[2], 'direction': 'D', 'row': 2};
        }

        //If no winner but the board is full, then it's a draw
        if(this.isFull()) {
            return {'winner': 'draw'};
        }
        
        //return false otherwise
        return false;
    }
}
/*-----------------------------------------------------------------------*/
/*-----------------------------------------------------------------------*/
/*-----------------------------------------------------------------------*/
/*-----------------------------------------------------------------------*/
/*-----------------------------------------------------------------------*/
/*-----------------------------------------------------------------------*/
/*-----------------------------------------------------------------------*/
class Player {
	constructor(max_depth = -1) {
        this.max_depth = max_depth;
        this.nodes_map = new Map();
    }
    /**
     * Uses minimax algorithm to get the best move
     * @param {Object} board - an instant of the board class
     * @param {Boolean} maximizing - whether the player is a maximizing or a minimizing player
     * @param {Function} callback - a function to run after the best move calculation is done
     * @param {Number} depth - used internally in the function to increment the depth each recursive call
     * @return {Number} the index of the best move
     */
	getBestMove(board, maximizing = true, callback = () => {}, depth = 0) {
		//Throw an error if the first argument is not a board
		if(board.constructor.name !== "Board") throw('The first argument to the getBestMove method should be an instance of Board class.');
		//Decides whether to log each tree iteration to the console
		//clear nodes_map if the function is called for a new move
		if(depth == 0) this.nodes_map.clear();

		//If the board state is a terminal one, return the heuristic value
		if(board.isTerminal() || depth == this.max_depth ) {
			if(board.isTerminal().winner == 'x') {
				return 100 - depth;
			} else if (board.isTerminal().winner == 'o') {
				return -100 + depth;
			} 
			return 0;
		}

		//Defining some styles for console logging
		const console_styles = {
			turn_and_available_moves: 'background: #7f3192; color: #fff; font-size:14px;padding: 0 5px;',
			exploring_parent: 'background: #353535;color: #fff;padding: 0 5px;font-size:18px',
			exploring_child: 'background: #f03;color: #fff;padding: 0 5px',
			parent_heuristic: 'background: #26d47c; color: #fff; font-size:14px;padding: 0 5px;',
			child_heuristic: 'background: #5f9ead; color: #fff; font-size:14px;padding: 0 5px;',
			all_moves: 'background: #e27a50;color: #fff;padding: 0 5px;font-size:14px',
			best_move: 'background: #e8602a;color: #fff;padding: 0 5px;font-size:18px'
		};
		//Destructuring Styles
		const {turn_and_available_moves, exploring_parent, exploring_child, child_heuristic, parent_heuristic, all_moves, best_move} = console_styles;


		//Current player is maximizing
		if(maximizing) {
			//Initializ best to the lowest possible value
			let best = -100;
			//Loop through all empty cells
			board.getAvailableMoves().forEach(index => {
				//Initialize a new board with the current state (slice() is used to create a new array and not modify the original)
				let child = new Board(board.state.slice());
				//Create a child node by inserting the maximizing symbol x into the current emoty cell
				child.insert('x', index);

				//Recursively calling getBestMove this time with the new board and minimizing turn and incrementing the depth
				let node_value = this.getBestMove(child, false, callback, depth + 1);
				//Updating best value
				best = Math.max(best, node_value);
				
				//If it's the main function call, not a recursive one, map each heuristic value with it's moves indicies
				if(depth == 0) {
					//Comma seperated indicies if multiple moves have the same heuristic value
					var moves = this.nodes_map.has(node_value) ? `${this.nodes_map.get(node_value)},${index}` : index;
					this.nodes_map.set(node_value, moves);
				}
			});
			//If it's the main call, return the index of the best move or a random index if multiple indicies have the same value
			if(depth == 0) {
				if(typeof this.nodes_map.get(best) == 'string') {
					var arr = this.nodes_map.get(best).split(',');
					var rand = Math.floor(Math.random() * arr.length);
					var ret = arr[rand];
				} else {
					ret = this.nodes_map.get(best);
				}
				//Console Tracing Code
				//run a callback after calculation and return the index
				callback(ret);
				return ret;
			}
			//If not main call (recursive) return the heuristic value for next calculation
			return best;
		}

		if(!maximizing) {
			//Initializ best to the highest possible value
			let best = 100;
			//Loop through all empty cells
			board.getAvailableMoves().forEach(index => {
				//Initialize a new board with the current state (slice() is used to create a new array and not modify the original)
				let child = new Board(board.state.slice());
				//Create a child node by inserting the minimizing symbol o into the current emoty cell
				child.insert('o', index);

			
				//Recursively calling getBestMove this time with the new board and maximizing turn and incrementing the depth
				let node_value = this.getBestMove(child, true, callback, depth + 1);
				//Updating best value
				best = Math.min(best, node_value);

				
				//If it's the main function call, not a recursive one, map each heuristic value with it's moves indicies
				if(depth == 0) {
					//Comma seperated indicies if multiple moves have the same heuristic value
					var moves = this.nodes_map.has(node_value) ? this.nodes_map.get(node_value) + ',' + index : index;
					this.nodes_map.set(node_value, moves);
				}
			});
			//If it's the main call, return the index of the best move or a random index if multiple indicies have the same value
			if(depth == 0) {
				if(typeof this.nodes_map.get(best) == 'string') {
					var arr = this.nodes_map.get(best).split(',');
					var rand = Math.floor(Math.random() * arr.length);
					var ret = arr[rand];
				} else {
					ret = this.nodes_map.get(best);
				}
				//Console Tracing Code
				//run a callback after calculation and return the index
				callback(ret);
				return ret;
			}
			//If not main call (recursive) return the heuristic value for next calculation
			return best;
		}

	}
}

/*-----------------------------------------------------------------------*/
/*-----------------------------------------------------------------------*/
/*-----------------------------------------------------------------------*/
/*-----------------------------------------------------------------------*/
/*-----------------------------------------------------------------------*/
/*-----------------------------------------------------------------------*/
/*-----------------------------------------------------------------------*/


//Obtendo os elementos do DOM com que vamos interagir

const casas = document.getElementsByTagName('input'); //pega a lista de casas do tabuleiro do jogo

const b_reiniciar = document.getElementById('reiniciar'); //pega o botão de reiniciar

const label_jogador = document.getElementById('jogador'); //pegar o label do jogador que usaremos para mostrar qual jogador tem a vez

const label_indica = document.getElementById('indicador');

const label_winner = document.getElementById('winner');

var eu = '';
var ia = '';

//Definindo variáveis de estado do jogo

var jogador = '_'; //Define o jogador atual (_ = jogador indefinido; X = jogador X, O = jogador O) 
var vencedor = '_'; //Define se há um vencedor ou não (_ = indefinido; X = jogador X, O = jogador O) 
var finish;
var board = new Board();
var player = new Player(4)
//Define a resposta ao evento de clique nas casas do "tabuleiro"

board.state.forEach((cell, index) => {
	casas[index].addEventListener('click', (event) => {
		//se a casa estiver vazia e ninguém tiver vencido a partida
		if( (event.target.value=='_') && (vencedor=='_')) {
			event.target.value=jogador; //preenche a casa com X ou O
			event.target.style.color='#bc5e00'; //torna o valor da casa visível

			board.insert(jogador, index)
			trocarJogador(); //função que troca a vez do jogador, a ser definida depois
			if(ia == 'x'){
				melhor_posicao = player.getBestMove(board, true, () => {});
			}else{
				melhor_posicao = player.getBestMove(board, false, () => {});
			}
			if(melhor_posicao != 0){
				vencedor = vitoria();
				casas[melhor_posicao].value = jogador;
				casas[melhor_posicao].innerText = jogador;
				casas[melhor_posicao].style.color = '#bc5e00';
				board.insert(jogador, melhor_posicao);
			}

			vencedor = vitoria(); //Executa a função vitoria() que defineremos depois, ela retorna o vencedor da partida, caso exista.
            if(vencedor == '_'){
				empate();
			}
			trocarJogador();
			//se o vencedor existe, imprime
		}
	});
})

//Define a resposta ao evento de clique no botão Reiniciar
b_reiniciar.addEventListener('click', (event) => {
	for(var i=0;i<9;i++) {
		casas[i].value='_'; //Limpa todas as casas
		casas[i].style.color='white'; //Torna o valor _ invisível
		casas[i].style.backgroundColor='white'; //Torna o fundo branco
	}
    indicador.innerText='Jogador atual: ';
    label_winner.innerText='';
	vencedor = '_'; //Reseta o vencedor
    history.go(0);
	sortearJogador(); //Escolhe aleatoriamente qual jogador irá começar
});

//Usa uma função que decide aleatoriamente o jogar a fazer a primeira jogada
var sortearJogador = function() {
	if(Math.floor(Math.random() * 2)==0) {
		jogador = "o"; //define o jogador O como atual
		eu = jogador;
		ia = 'x';
		label_jogador.innerText="O"; //exibe na página qual é o jogador atual
		label_jogador.style.color='#ffffff'; //deixa o texto na cor vermelha
        label_indica.style.color="#ffffff";
	}else{
		jogador = "x";//define o jogador X como atual
		eu = jogador;
		ia = 'o';
		label_jogador.innerText="X"; //exibe na página qual é o jogador atual
		label_jogador.style.color='#262730'; //deixa o texto na cor azul
        label_indica.style.color="#262730";
	}
}

sortearJogador(); //Escolhe aleatoriamento o jogador inicial

//Alterna a vez entre os jogadores X e Y
var trocarJogador = function() {
	if(jogador=='x') {
		jogador='o';
		label_jogador.innerText='O';
		label_jogador.style.color='#ffffff';
        indicador.style.color="#ffffff";
		
	}else{
		jogador='x';
		label_jogador.innerText='x';
		label_jogador.style.color='#262730';
        indicador.style.color='#262730';
	}
}

//Verifica se uma condição de vitória foi atingida e colore a linha da vitória
var vitoria = function() {
	if((casas[0].value==casas[1].value) && (casas[1].value==casas[2].value) && casas[0].value!='_' ) {
		casas[0].style.backgroundColor='#40F99B';
		casas[1].style.backgroundColor='#40F99B';
		casas[2].style.backgroundColor='#40F99B';

        label_winner.innerText='Parabéns ' + casas[0].value + '!';
		return casas[0].value;

	}else if((casas[3].value==casas[4].value) && (casas[4].value==casas[5].value) && casas[3].value!='_' ) {
		casas[3].style.backgroundColor='#40F99B';
		casas[4].style.backgroundColor='#40F99B';
		casas[5].style.backgroundColor='#40F99B';

        label_winner.innerText='Parabéns ' + casas[3].value + '!';
		return casas[3].value;

	}else if((casas[6].value==casas[7].value) && (casas[7].value==casas[8].value) && casas[6].value!='_' ) {
		casas[6].style.backgroundColor='#40F99B';
		casas[7].style.backgroundColor='#40F99B';
		casas[8].style.backgroundColor='#40F99B';

        label_winner.innerText='Parabéns ' + casas[6].value + '!';
		return casas[6].value;

	}else if((casas[0].value==casas[3].value) && (casas[3].value==casas[6].value) && casas[0].value!='_' ) {
		casas[0].style.backgroundColor='#40F99B';
		casas[3].style.backgroundColor='#40F99B';
		casas[6].style.backgroundColor='#40F99B';

        label_winner.innerText='Parabéns ' + casas[0].value + '!';
		return casas[0].value;

	}else if((casas[1].value==casas[4].value) && (casas[4].value==casas[7].value) && casas[1].value!='_' ) {
		casas[1].style.backgroundColor='#40F99B';
		casas[4].style.backgroundColor='#40F99B';
		casas[7].style.backgroundColor='#40F99B';

        label_winner.innerText='Parabéns ' + casas[1].value + '!';
		return casas[1].value;

	}else if((casas[2].value==casas[5].value) & (casas[5].value==casas[8].value) && casas[2].value!='_' ) {
		casas[2].style.backgroundColor='#40F99B';
		casas[5].style.backgroundColor='#40F99B';
		casas[8].style.backgroundColor='#40F99B';

        label_winner.innerText='Parabéns ' + casas[2].value + '!';
		return casas[2].value;

	}else if((casas[0].value==casas[4].value) && (casas[4].value==casas[8].value) && casas[0].value!='_' ) {
		casas[0].style.backgroundColor='#40F99B';
		casas[4].style.backgroundColor='#40F99B';
		casas[8].style.backgroundColor='#40F99B';

        label_winner.innerText='Parabéns ' + casas[0].value + '!';
		return casas[0].value;

	}else if((casas[2].value==casas[4].value) && (casas[4].value==casas[6].value) && casas[2].value!='_' ) {
		casas[2].style.backgroundColor='#40F99B';
		casas[4].style.backgroundColor='#40F99B';
		casas[6].style.backgroundColor='#40F99B';

        label_winner.innerText='Parabéns ' + casas[2].value + '!';
		return casas[2].value;
	}
								
    return '_';
}

var empate = function() {
    var contagem = 0;
    for(var i=0; i<9; i++) {
        if(casas[i].value != '_'){
            contagem++;
        }
    }
    if(contagem == 9){
        label_winner.innerText="Deu empate!";
    }
}